﻿using UnityEngine;
using System;

namespace PolyPerfect
{
  [Serializable]
  public class AIState
  {
    public string stateName = "New State";
    public string animationBool = string.Empty;
  }
}